g++ -std=c++11 multiMessenger.cc -o multiMessenger `root-config --cflags --glibs`
